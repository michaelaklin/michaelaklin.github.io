
%	************************************************************************
% 	File-Name: 	SpatialEffectAklin.m
%	Date:  		05/20/2015
%	Author: 	Micha�l Aklin
%	Data Used:  Various. The datasets were generated separately.
%
%	Purpose:   	Matlab file to compute the spatial effects in:
%				Aklin, Micha�l. 2015. "Re-exploring the Trade and Environment 
%				Nexus Through the Diffusion of Pollution." Environmental and
%				Resource Economics.
%
%               The code borrows on earlier code by Jude Hays (2006).
%
%	Note:		This file should only require few changes (e.g. path to
%				dataset).
%	************************************************************************


% Main results
clear all;
A=csvread('YX.csv');
W1=csvread('W.csv');

nobs = 196;

W_LR=normw(W1);
I_T = eye(58); % 58 obs per country
W1_TSCS = kron(I_T,W1);
W=(normw(W1_TSCS)); %normw

y=A(:,[1]); % column number in the data matrix that corresponds to the dependent variable
x=A(:,[2,3,4]); % column numbers in the data matrix that correspond to the independent variables

xconstant=ones(11368,1);
info.rmin=-.9;
info.rmax=.9;
info.lflag=0; % 0 required for exact results

results=sar(y,[xconstant x],W,info);
vnames=char('y','constant','GDPcap','GDPcap2','year');
prt(results,vnames);


% With Country FE
clear all;
A=csvread('YXCFE.csv');
W1=csvread('W.csv');

nobs = 196;

W_LR=normw(W1);
I_T = eye(58); % 58 obs per country
W1_TSCS = kron(I_T,W1);
W=(normw(W1_TSCS)); %normw

y=A(:,[1]); % column number in the data matrix that corresponds to the dependent variable
x=A(:,[2,3,4]); % column numbers in the data matrix that correspond to the independent variables

xconstant=ones(11368,1);
info.rmin=-.9;
info.rmax=.9;
info.lflag=0; % 0 required for exact results

results=sar(y,[xconstant x],W,info);
vnames=char('CO2 per capita','Constant','GDPcap','GDPcap2','Year');
prt(results,vnames);


% With Country and Year FE
clear all;
A=csvread('YXCYFE.csv');
W1=csvread('W.csv');

nobs = 196;

W_LR=normw(W1);
I_T = eye(58); % 58 obs per country
W1_TSCS = kron(I_T,W1);
W=(normw(W1_TSCS)); %normw

y=A(:,[1]); % column number in the data matrix that corresponds to the dependent variable
x=A(:,[2,3]); % column numbers in the data matrix that correspond to the independent variables

xconstant=ones(11368,1);
info.rmin=-.9;
info.rmax=.9;
info.lflag=0; % 0 required for exact results

results=sar(y,[xconstant x],W,info);
vnames=char('CO2 per capita','Constant','GDPcap','GDPcap2');
prt(results,vnames);

resultsDurbin=sdm(y,[xconstant x],W,info);
vnames=char('CO2 per capita','Constant','GDPcap','GDPcap2');
prt(resultsDurbin,vnames);

