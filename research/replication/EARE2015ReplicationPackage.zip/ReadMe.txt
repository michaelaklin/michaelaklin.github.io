


* ************************************************************************
* File Name:	ReadMe.txt
* Author:	Michaël Aklin
* Date:		05/20/2015
* Purpose	This is the ReadMe file for the replication package of:
*		Aklin, Michaël. 2015. 
*		”Re-exploring the Trade and Environment Nexus Through the Diffusion of Pollution." Environmental and Resource Economics.
*	************************************************************************


The zip file EARE2015ReplicationPackage.zip contains the following files:

(1) ReadMe.txt			The current file
(2) AppendixFinal.pdf		The appendix (referred to in the main manuscript)
(3) AklinEAREData.dta		Main dataset (in Stata .dta format)
(4) AklinEAREAnalysis.do	Do file to replicate the results in the manuscript
(5) AklinEAREAppendix.do	Do file to replicate the appendix
(6) SpatialEffectAklin.m	Matlab file to replicate some results from the manuscript
(7) W.csv, YX.csv, YXCFE.csve, and YXCYFE.csv
				CSV data used as input in the matlab file.

Therefore, to replicate the results from the manuscript, please refer to AklinEAREAnalysis.do and adapt the path to the dataset. To do the same for the appendix, run AklinEAREAppendix.do. The matlab file SpatialEffectAklin.m compiles the code needed to get some of the results in the manuscript (on the spatial effects). This code is adapted from earlier work by Jude Hays - all errors are mine. 

In case there is any question, please get in touch:
Michaël Aklin
aklin@pitt.edu
http://www.pitt.edu/~aklin/
